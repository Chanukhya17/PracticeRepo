﻿//using System.Net.Mail;

//namespace User.Management.API.NewFolder
//{
//    public class EmailSender : IEmailSender
//    {
//        public Task sendEmail(string email, string subject, string message)
//        {
//            var mail = "kandranikhil17@gmail.com";
//            var pw = "27F3A7D8244F2C528E271846ED6AA80150A9";

//            var client=new SmtpClient("smtp.elasticmail.com",2525)
//        }
//    }
//}
